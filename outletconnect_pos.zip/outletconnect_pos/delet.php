<?php
require_once('connect.php');

if(@$_COOKIE['user'])
{
	$num = $_COOKIE['user'];
	$prod = $_GET['prod'];
	$sql = "DELETE FROM live_bill WHERE number = '$num' && prod_name = '$prod'";
if ($con->query($sql) === TRUE) {
	
	}
else {
    
}

}
?>