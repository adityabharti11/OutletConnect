<?php
require_once('connect.php');

?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="css/styles.css">
		<script src="script.js"></script>
		<style>
		.button {
			background-color: #4CAF50; /* Green */
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
		}

#btncompare {
  position: fixed;
  right: 24px;
  bottom: 31px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
		</style>
	</head>
	<body>
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btncompare"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Inventory </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>

	<div class="content">
	<div style="text-align:left;float:left;">
		<span>Outlet INVENTORY Recent Expire</span><br>
	</div>
	<div style="text-align:right;">		
		<a class="button" href ="logout.php">Logout</a>
	</div>
	<br>
		<article>
			<table class="inventory">
				<thead>
					<tr>
						<th><span >Item</span></th>
						<th><span >Quantity</span></th>
					</tr>				
					</thead>

					<?php 
						$get_inve = mysqli_query($con,"SELECT * FROM inventory where going_exp='1'");
						while($row = mysqli_fetch_array($get_inve))
						{
							?>
							<tr>
								<td><span ><?php echo $row['prod_name'];?></span></td>
								<td><span ><?php echo $row['quant'];?></span></td>
							</tr>
					<?php	
					}
					?>
				<tbody class="new_inv">
					
				</tbody>
			</table>
			
		</article>
</div>




<script src="js/ajax.js"></script>

	</body>
</html>