<?php
require_once('connect.php');

if($_SERVER["REQUEST_METHOD"] == "GET" )
{
	$number = $_GET['numb'];
		$get_info = mysqli_query($con,"SELECT * FROM live_bill WHERE number = '$number'");
		while($row = mysqli_fetch_array($get_info))
		{
			$bill_no = $row['bill_no'];
			$number = $row['number'];
			$barcode = $row['barcode'];
			$prod_name = $row['prod_name'];
			$quant = $row['quant'];
			$price = $row['price'];
			$final_value = $row['final_value'];
			$exp_val = $row['exp_after'];
		
			$sql = "INSERT INTO billing (bill_no,number,barcode,prod_name,quant,price,final_value) 
					VALUES ('$bill_no','$number','$barcode','$prod_name','$quant','$price','$final_value')";
				if ($con->query($sql) === TRUE) {
					echo "yes";
				} else {
					echo "no";
				}
				
			$sql = "DELETE FROM live_bill WHERE number = '$number'";
			if ($con->query($sql) === TRUE) {
					echo "yes";
				}
			else {
				
			}
			if($exp_val<2)
			{
				$sql_inv = "UPDATE inventory SET quant = quant-1, going_exp='1' WHERE  prod_name= '$prod_name'";
				if ($con->query($sql_inv) === TRUE) {
					
				} else {
					
				}
			}
			else{
				$sql_inv = "UPDATE inventory SET quant = quant-1 WHERE  prod_name= '$prod_name'";
				if ($con->query($sql_inv) === TRUE) {
					
				} else {
					
				}
			}
		
		}
	setcookie( 'bill_no',null, time() + (24 * 60 * 60));
	header("Location:home.php");
		
}
?>