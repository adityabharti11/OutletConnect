<?php
require_once('connect.php');
$st_id = "DEL0000000004";
$count_id = "Counter1";		
$exp=0;
$aft =0;		
if($_SERVER["REQUEST_METHOD"] == "POST" )
{
	if(isset($_COOKIE['bill_no']))
	{	
		$bill_no = $_COOKIE['bill_no'];	
	}
	else
	{
		$get_bill = mysqli_query($con,"SELECT max(id) as id FROM billing");
			while($row = mysqli_fetch_array($get_bill))
			{
				$ids = $row['id'];
			}
			if($ids==null)
			{
				$ids = 1;
			}
			
			$bill_no  = $count_id.$st_id.$ids;	
			setcookie( 'bill_no',$bill_no, time() + (24 * 60 * 60));
	}
	
	if(isset($_POST['numb']))
	{
		$numb = $_POST['numb'];
		$contact = $_POST['contact'];
		
		$get_info = mysqli_query($con,"SELECT * FROM product_master WHERE BARCODE = '$numb'");
		while($row = mysqli_fetch_array($get_info))
		{
			$prod_name = $row['BASEPACK_DESC'];
			$price = $row['price'];
		}
		$final_value = $price;
		
		/*New */
		$get_exp = mysqli_query($con,"SELECT * FROM product_master  WHERE BARCODE = '$numb'");
		while($row = mysqli_fetch_array($get_exp))
		{
			$str = $row['pkd_date'];
			$str2 = $row['exp'];
			
			$pieces = explode("-", $str);
			
			$year = $pieces[0];
			$month = $pieces[1];
			
			if($pieces[1]+$str2>12)
			{
				$expmonth =  ($pieces[1]+$str2)%12; // piece2
				$expyear = $pieces[0]+1;
			}
			else
			{
				$expmonth =  ($pieces[1]+$str2)%12; // piece2
				$expyear = $pieces[0];
			}
			
			
			$now = DATE("Y-m-d");
			$no = explode("-", $now);
			$nyear = $no[0];
			$nmonth = $no[1];

			
			if($nyear>$expyear)
			{
				$exp=1;
			}
			else if ($nyear<$expyear)
			{
				$exp=0;
			}
			else{
				if($nmonth>$expmonth)
				{
					$exp=1;	
				}
				else{
					$exp=0;
					$aft = $expmonth-$nmonth;
				}
			}
		}
		/*New */		

		$sql = "INSERT INTO live_bill (bill_no,number,barcode,prod_name,price,final_value,exp,exp_after) VALUES ('$bill_no','$contact','$numb','$prod_name','$price','$final_value','$exp','$aft')";
			if ($con->query($sql) === TRUE) {
				echo $prod_name."is scanned";
			} else {
				echo "Try again";
			}
	}
	
}
?>