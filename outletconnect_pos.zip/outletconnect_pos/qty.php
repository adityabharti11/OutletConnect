<?php

require_once('connect.php');

if(isset($_GET['prod']))
{
	$numb = $_COOKIE['user'];
	$prod = $_GET['prod'];
	$value = $_GET['value'];  	

	$get_info = mysqli_query($con,"SELECT * FROM live_bill WHERE number = '$numb' && prod_name = '$prod'");
		while($row = mysqli_fetch_array($get_info))
		{
			$rate = $row['price'];
		}			
	$price = $rate * $value;  	
	$sql = "UPDATE live_bill SET final_value = '$price' , quant = '$value' WHERE  prod_name= '$prod' && number = '$numb'";
			if ($con->query($sql) === TRUE) {
				
			} else {
				
			}
}

?>