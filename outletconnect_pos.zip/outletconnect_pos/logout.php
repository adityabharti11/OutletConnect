<?php
if(@$_COOKIE['user_active'])
{
setcookie( 'user',null, time() + (24 * 60 * 60));
setcookie( 'user_counter',null, time() + (24 * 60 * 60));
setcookie( 'user_id',null, time() + (24 * 60 * 60));
setcookie( 'user_outlet',null, time() + (24 * 60 * 60));
setcookie( 'user_active',null, time() + (24 * 60 * 60));
header("location: index.php");
}
else
{
header("location: index.php");
}
?>
	