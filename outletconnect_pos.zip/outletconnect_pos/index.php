<?php
require_once('connect.php');
if(@$_COOKIE['user_active'])
{
header("Location:home.php");
}
$passw = "";
$cmp = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		$user = $_POST['uname'];
		$pass = $_POST['psw'];
		
$result = mysqli_query($con,"SELECT * FROM users WHERE username = '$user' && password = '$pass'");
if($row = mysqli_fetch_array($result))
{
	$passw = $row['password'] ;
	$user = $row['username'] ;
	$outlet_name = $row['outlet_name'] ;
	$outlet_counter = $row['outlet_counter'] ;
	$id = $row['id'] ;
	$cmp = strcmp($_POST["psw"], $passw);
	if($cmp == 0)
	{	
		setcookie( 'user_active',$user, time() + (24 * 60 * 60));
		setcookie( 'user_id',$id, time() + (24 * 60 * 60));
		setcookie( 'user_counter',$outlet_counter, time() + (24 * 60 * 60));
		setcookie( 'user_outlet',$outlet_name, time() + (24 * 60 * 60));
		header("Location:home.php");
	}
	else
	{
	header("Location:index.php");
	}
}
}


?>
<!DOCTYPE html>
<html>
<style>
/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}


button:hover {
    opacity: 0.8;
}


/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 24px 0 12px 0;
    position: relative;
}

img.avatar {
    width: 21%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Modal (background) */
.modal {
    display: block; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 318px;
    top: 20px;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
}

/* Modal Content/Box */
.modal-content {
    background-color: #fefefe;
    margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
    border: 1px solid #888;
    width: 37%; /* Could be more or less, depending on screen size */
}



/* Add Zoom Animation */
.animate {
    -webkit-animation: animatezoom 0.6s;
    animation: animatezoom 0.6s
}

@-webkit-keyframes animatezoom {
    from {-webkit-transform: scale(0)} 
    to {-webkit-transform: scale(1)}
}
    
@keyframes animatezoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
    span.psw {
       display: block;
       float: none;
    }

}
</style>
<body>
<div style="float:left;">
<img src="images/invoice.png" style="width:640px;">
</div>
<div id="id01" class="modal">
  
  <form class="modal-content animate" action="" method="POST">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="images/img_avatar2.png" alt="Avatar" class="avatar">
    </div>

    <div class="container">
      <label><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="uname" required>

      <label><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="psw" required>
        
      <button type="submit">Login</button>
      <input type="checkbox" checked="checked"> Remember me
    </div>

  </form>
</div>


</body>
</html>
