<?php
require_once('connect.php');
$pro='0';
if(@$_COOKIE['user'])
{
	$num = $_COOKIE['user'];
	setcookie( 'user', null, time() + (24 * 60 * 60));
	$sql = "DELETE FROM live_bill WHERE number = '$num'";
if ($con->query($sql) === TRUE) {
	}
else {
    
}

}
if(@$_COOKIE['user_active'])
{
	$id = $_COOKIE['user_id'];
	$get_info = mysqli_query($con,"SELECT * FROM users WHERE id = '$id'");
		while($row = mysqli_fetch_array($get_info))
		{
			$name = $row['name'];
			$addr = $row['address'];
			$phn = $row['phone'];
		}
	$pro = '1';
}
else
{
	header("Location:index.php");
}



?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="css/styles.css">
		<script src="script.js"></script>
		<style>
		.button {
			background-color: #4CAF50; /* Green */
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
		}

#btncompare {
  position: fixed;
  right: 24px;
  bottom: 31px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}

#btnexp {
  position: fixed;
  right: 24px;
  bottom: 80px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnsupport {
  position: fixed;
  right: 24px;
  bottom: 130px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnonline {
  position: fixed;
  right: 24px;
  bottom: 180px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnhistory {
  position: fixed;
  right: 24px;
  bottom: 230px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnpromo {
  position: fixed;
  right: 24px;
  bottom: 280px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
		</style>
	</head>
	<body>
	<div class="compare_drpdn">
			<a href="billhistory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnhistory"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Billing History</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnpromo"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Promotion/launch</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnonline"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Online Order</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>		
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnsupport"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Support</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>		
	
	<div class="compare_drpdn">
			<a href="goingexp.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnexp"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Going to Expire </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btncompare"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Inventory </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>

	<div class="content">
	<div style="text-align:left;float:left;">
	</div>
	<div style="text-align:right;">		
		<a class="button" href ="logout.php">Logout</a>
	</div>
	<br>
		<header>
			<h1>Invoice</h1>
			<address >
				<p><?php echo $name; ?></p>
				<p><?php echo $addr; ?></p>
				<p><?php echo $phn; ?></p>
			</address>
			<span style="color:#007dbb;font-size:25px;"><?php echo $_COOKIE['user_outlet']."<br><span style='color:#000;font-size:20px;'>".$_COOKIE['user_counter']."</span>"; ?></span>
		</header>
		<article>
			<address >
			Customer:
			<br><br>
				<p class="mobile_cust"></p>
			</address>
			<table class="meta">
				<tr>
					<th><span >Invoice #</span></th>
					<td class="bill_no"><span class="bill_nn" style="font-size:11px;"></span></td>
				</tr>
				<tr>
					<th><span >Date</span></th>
					<td><span ><?php echo date('d-m-Y');?></span></td>
				</tr>
				<tr>
					<th><span >Amount Due</span></th>
					<td><span id="prefix" >Rs</span> <span> 000.00</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span >Item</span></th>
						<th><span >Description</span></th>
						<th><span >Rate</span></th>
						<th><span >Quantity</span></th>
						<th><span >Price</span></th>
					</tr>
				</thead>
				<tbody class="new_inv">
					
				</tbody>
			</table>
			<table class="balance">
				<tr>
					<th><span >Total</span></th>
					<td><span data-prefix>Rs </span> <span>600.00</span></td>
				</tr>
				<tr>
					<th><span >Amount Paid</span></th>
					<td><span data-prefix>Rs </span> <span >0.00</span></td>
				</tr>
				<tr>
					<th><span >Balance Due</span></th>
					<td><span data-prefix>Rs </span> <span>600.00</span></td>
				</tr>
			</table>
		</article>
		<div style="text-align:right;">
			<a class="button confirm" href ="#">Confirm</a>
		</div>	
</div>




<script src="js/ajax.js"></script>
<script>
var numb;
function updates()
{
var exe = 0;	
				if(checkCookie())
				{
					exe = 1;
				}
				else{
					numb = 0;
				}
				var dataString = 'number='+numb;
				$.ajax({
				type: "GET",
				url: "http://localhost/hul/update.php?number="+numb,
				data: dataString,
				cache: false,
				success: function(html)
				{
					
					var price = html.split('_')[0];
					if(price=="na")
					{
						
					}
					else
					{
						var number = html.split('_')[1];
						var bill_no = html.split('_')[2];
						var prod_name = html.split('_')[3];
						var quanty = html.split('_')[4];
						var bill_no = html.split('_')[5];
						var exp = html.split('_')[6];
						numb = number;
						if(exe == 1)
						{
							
						}
						else{
							$(".mobile_cust").append(number);
							$(".bill_nn").append(bill_no);
							setCookie("user",number,365);
						}
						if(exp==1)
						{
							$(".new_inv").append(
							"<tr style='background-color:red;'><td><a class='cut'>-</a><span class='prodd_name' value='"+prod_name+"'>"+prod_name+"</span></td><td><span>Skin_care</span></td><td><span data-prefix>Rs </span> <span>"+price+"</span></td><td><span contenteditable id='qty'>"+quanty+"</span></td><td><span data-prefix>Rs </span> <span>"+(price*quanty).toFixed(2)+"</span></td></tr>"
							);
							
						}
						else{
							$(".new_inv").append(
							"<tr><td><a class='cut'>-</a><span class='prodd_name' value='"+prod_name+"'>"+prod_name+"</span></td><td><span>Skin_care</span></td><td><span data-prefix>Rs </span> <span>"+price+"</span></td><td><span contenteditable id='qty'>"+quanty+"</span></td><td><span data-prefix>Rs </span> <span>"+(price*quanty).toFixed(2)+"</span></td></tr>"
							);
						}
					}
					
					
						
					//setInterval(updates, 5000);
					updates();
				}
			  });
}
updates();

function setCookie(cname, cvalue, exdays) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000));
    var expires = "expires="+ d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/hul";
}

function checkCookie() {
    var user = getCookie("user");
    if (user != "") {
        return 1;
    }else{
		return 0;
	}
}
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


$('.confirm').click(function() {
	
	window.location = "confirm.php?numb="+getCookie("user");
	
});
	</script>
	</body>
</html>