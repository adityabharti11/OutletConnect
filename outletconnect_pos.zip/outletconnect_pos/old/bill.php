<?php
require_once('../connect.php');

if(@$_COOKIE['user_active'])
{
	$id = $_COOKIE['user_id'];
	$get_info = mysqli_query($con,"SELECT * FROM users WHERE id = '$id'");
		while($row = mysqli_fetch_array($get_info))
		{
			$name = $row['name'];
			$addr = $row['address'];
			$phn = $row['phone'];
		}
	$pro = '1';
}
else
{
	header("Location:index.php");
}
define('DB_SERVER', 'localhost');
						define('DB_USERNAME', 'root');
						define('DB_PASSWORD', 'aditya');
						define('DB_DATABASE', 'hul_old');
						$conn = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
$bill =  @$_POST['bill'];
$mob ="";
$get_bill = mysqli_query($conn,"SELECT DISTINCT BILLNO,BARCODE,cou FROM billing WHERE BILLNO = '$bill'");
								while($row = mysqli_fetch_array($get_bill))
								{
									$num = $row['BARCODE'];
									$cou = $row['cou'];
									if(strlen($num)=='10')
									{
											$mob = $num;
											$flag =1;
									}
									if($flag==1)
										break;
								}
?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="../css/styles.css">
		<style>
		.button {
			background-color: #4CAF50; /* Green */
			border: none;
			color: white;
			padding: 15px 32px;
			text-align: center;
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
		}

#btncompare {
  position: fixed;
  right: 24px;
  bottom: 31px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}

#btnexp {
  position: fixed;
  right: 24px;
  bottom: 80px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnsupport {
  position: fixed;
  right: 24px;
  bottom: 130px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnonline {
  position: fixed;
  right: 24px;
  bottom: 180px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnhistory {
  position: fixed;
  right: 24px;
  bottom: 230px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnpromo {
  position: fixed;
  right: 24px;
  bottom: 280px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
		</style>
	</head>
	<body>
	<div class="compare_drpdn">
			<a href="billhistory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnhistory"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Billing History</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnpromo"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Promotion/launch</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnonline"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Online Order</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>		
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnsupport"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Support</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>		
	
	<div class="compare_drpdn">
			<a href="goingexp.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnexp"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Going to Expire </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btncompare"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Inventory </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>

	<div class="content">
	<div style="text-align:left;float:left;">
	</div>
	<div style="text-align:right;">		
		<a class="button" href ="logout.php">Logout</a>
	</div>
	<br>
		<header>
			<h1>Invoice</h1>
			<address >
				<p><?php echo $name; ?></p>
				<p><?php echo $addr; ?></p>
				<p><?php echo $phn; ?></p>
			</address>
			<span style="color:#007dbb;font-size:25px;"><?php echo $_COOKIE['user_outlet']."<br><span style='color:#000;font-size:20px;'>".$_COOKIE['user_counter']."</span>"; ?></span>
		</header>
		<article>
			<address >
			BillNo:	<form method="POST" action=""><input class="check_bill" name="bill" type="text" style="broder:2px !important;"/></form>
			<br>
			Customer : <?php echo $mob;?>
			<br><br>
				<p class="mobile_cust"></p>
			</address>
			<table class="meta">
				<tr>
					<th><span >Invoice #</span></th>
					<td class="bill_no"><span class="bill_nn" style="font-size:9px;"><?php echo $bill;?></span></td>
				</tr>
				<tr>
					<th><span >Date</span></th>
					<td><span ><?php echo date('d-m-Y');?></span></td>
				</tr>
				<tr>
					<th><span >Amount Due</span></th>
					<td><span id="prefix" >Rs</span> <span> 0.00</span></td>
				</tr>
			</table>
			<table class="inventory">
				<thead>
					<tr>
						<th><span >Barcode</span></th>
						<th><span >item</span></th>
						<th><span >Rate</span></th>
						<th><span >Quantity</span></th>
						<th><span >Price</span></th>
					</tr>
				</thead>
				<tbody class="new_inv">
					<?php
					
						
						$get_bill = mysqli_query($conn,"SELECT DISTINCT BILLNO,BARCODE,cou,product_name FROM billing WHERE BILLNO = '$bill'");
								while($row = mysqli_fetch_array($get_bill))
								{
									$num = $row['BARCODE'];
									$cou = $row['cou'];
									$nam = $row['product_name'];
									if(strlen($num)=='10')
									{
										
									}
									else
									{?>
											<tr>
												<td>
													<span class='prodd_name' value=''><?php if(strlen($num)=='13') echo $num; else if(strlen($num)>'3') echo $num." ---(Start or end of barcode)" ;else echo $num." ---(garbage)" ;?></span>
													</td>
												<td><span><?php echo $nam; ?></span></td>
												<td><span>Rs </span> <span>From Master Table</span></td>
												<td><span id='qty'><?php echo $cou; ?></span></td>
												<td><span data-prefix>Rs </span> <span> (Quantity * Rate) </span></td>
											</tr>
									
									<?php
									}
								}
						?>
				</tbody>
			</table>
			<table class="balance">
				<tr>
					<th><span >Total</span></th>
					<td><span data-prefix>Rs </span> <span>0.00</span></td>
				</tr>
				<tr>
					<th><span >Amount Paid</span></th>
					<td><span data-prefix>Rs </span> <span >0.00</span></td>
				</tr>
				<tr>
					<th><span >Balance Due</span></th>
					<td><span data-prefix>Rs </span> <span>0.00</span></td>
				</tr>
			</table>
		</article>

</div>
<script src="../js/ajax.js"></script>

	</body>
</html>