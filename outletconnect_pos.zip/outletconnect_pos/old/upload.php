<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.no-icons.min.css">
</head>
<body>
<h2 style="text-align:center;">Upload Report</h2>
<div class="card">
	<form action="uploads.php" method="post" enctype="multipart/form-data" style="margin-top:10%;">
		<div style="position:relative;float:left;margin-left:37%;">
			<a class='btn btn-primary' href='javascript:;'>
				Choose File...
				<input type="file" style='position:absolute;z-index:2;top:0;left:0;filter: alpha(opacity=0);-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";opacity:0;background-color:transparent;color:transparent;' name="file" size="40"  onchange='$("#upload-file-info").html($(this).val());'>
			</a>
			&nbsp;
			<span class='label label-info' id="upload-file-info"></span>
		</div>
		<div style="position:relative;float:right;margin-right:30%;"> 
			<input type="submit" value="Upload Error" name="submit">
		</div>
	</form>
	<br>
	<form action="uploads.php" method="post" enctype="multipart/form-data" style="margin-top:20%;">
		<div style="position:relative;float:left;margin-left:37%;">
			<a class='btn btn-primary' href='javascript:;'>
				Choose File...
				<input type="file" style='position:absolute;z-index:2;top:0;left:0;filter: alpha(opacity=0);-ms-filter:"progid:DXImageTransform.Microsoft.Alpha(Opacity=0)";opacity:0;background-color:transparent;color:transparent;' name="file" size="40"  onchange='$("#upload-file-info").html($(this).val());'>
			</a>
			&nbsp;
			<span class='label label-info' id="upload-file-info"></span>
		</div>
		<div style="position:relative;float:right;margin-right:30%;"> 
			<input type="submit" value="Upload Master" name="submit">
		</div>
	</form>
</div>
</body>
	<script src="http://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>
	<script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
</html>