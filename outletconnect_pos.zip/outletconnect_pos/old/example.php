<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'aditya');
define('DB_DATABASE', 'hul_old');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
 $i=1;
	$get_info = mysqli_query($con,"SELECT BILLNO,BARCODE FROM billing");
		while($row = mysqli_fetch_array($get_info))
			{
				$bill = $row['BILLNO'];
				$bar = $row['BARCODE'];
				$get_bar = mysqli_query($con,"SELECT count(BARCODE) as bar_count,BARCODE,BILLNO,POS_Application_Name,STOREID,MACID,GUID,CREATED_STAMP,CAPTURED_WINDOW,UPDATE_STAMP,ver,dat FROM billing WHERE BILLNO='$bill' && BARCODE  = '$bar'");
				while($row = mysqli_fetch_array($get_bar))
				{
					$bills = $row['BILLNO'];
					$bar = $row['BARCODE'];
					$cou = $row['bar_count'];
					echo $i."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$bills."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$bar."&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$cou."<br>";
					$i++;	
					
					$sql = "ALTER TABLE billing ADD cou INT(3) AFTER dat";
					if ($con->query($sql) === TRUE) {
						
					} else {
						
					}
					$sql = "UPDATE billing SET cou = '$cou' WHERE  BILLNO='$bill' && BARCODE  = '$bar'";
					if ($con->query($sql) === TRUE) {
						
					} else {
						
					}
					
				}
			}
?>