<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'aditya');
define('DB_DATABASE', 'bsnl');
$connection = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);
 
ini_set("display_errors",1);
require_once 'excel_reader2.php';
 
$data = new Spreadsheet_Excel_Reader("BTS LIST 19052017.xls");
 
//echo "Total Sheets in this xls file: ".count($data->sheets)."<br /><br />";
 
//$html="<table border='1'>";
for($i=0;$i<count($data->sheets);$i++) // Loop to get all sheets in a file.
{	
	if(@count($data->sheets[$i][cells])>0) // checking sheet not empty
	{
		mysqli_query($connection,'TRUNCATE TABLE master_site;');
		//echo "Sheet $i:<br /><br />Total rows in sheet $i  ".@count($data->sheets[$i][cells])."<br />";
		for($j=1;$j<=@count($data->sheets[$i][cells]);$j++) // loop used to get each row of the sheet
		{ 
			//$html.="<tr>";
			for($k=1;$k<=@count($data->sheets[$i][cells][$j]);$k++) // This loop is created to get data in a table format.
			{
				/*$html.="<td>";
				$html.=@$data->sheets[$i][cells][$j][$k];
				$html.="</td>";*/
			}
			$vid = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][1]);
			$stype = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][2]);
			$ip_name = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][3]);
			$btsname = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][4]);
			$area = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][5]);
			$divty = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][6]);
			$remarks = mysqli_real_escape_string($connection,@$data->sheets[$i][cells][$j][7]);
			$query = "insert into master_site(vendor_id,site_type, ip_name, site_name, area, device_type, remarks) values('".$vid."','".$stype."','".$ip_name."','".$btsname."','".$area."','".$divty."','".$remarks."')";
 
			mysqli_query($connection,$query);
			//$html.="</tr>";
		}
	}
 
}
 
//$html.="</table>";
//echo $html;
//echo "<br />Data Inserted in dababase";
?>