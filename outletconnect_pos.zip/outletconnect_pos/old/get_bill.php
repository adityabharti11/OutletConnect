<?php

define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'aditya');
define('DB_DATABASE', 'hul_old');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

if(isset($_GET['bill_no']))
{
	$numb = $_GET['bill_no'];	

	$get_info = mysqli_query($con,"SELECT DISTINCT BILLNO,BARCODE,cou FROM billing WHERE BILLNO = '$numb'");
		while($row = mysqli_fetch_array($get_info))
		{
			$num = $row['BARCODE'];
			$cou = $row['cou'];
			if(strlen($num)=='10')
			{
				echo "Con_".$num;
			}
			else
			{
				echo $num."_".$cou;
			}
		}			
}

?>