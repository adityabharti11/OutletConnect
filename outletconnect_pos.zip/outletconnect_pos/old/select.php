<?php
$i=1;
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'aditya');
define('DB_DATABASE', 'hul_old');
$con = mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_DATABASE);

	$get_info = mysqli_query($con,"SELECT DISTINCT BILLNO,BARCODE,dat FROM billing");
		while($row = mysqli_fetch_array($get_info))
			{
				$bill = $row['BILLNO'];
				$bar = $row['BARCODE'];
				$dat = $row['dat'];
				echo $i."&nbsp;&nbsp;&nbsp;&nbsp;".$bill."".$bar.$dat."<br>";
				$i++;
			}
?>