<?php
$output_dir = "";
if(isset($_FILES["file"]))
{
//Filter the file types , if you want.
if ($_FILES["file"]["error"] > 0)
{
echo "Error: " . $_FILES["file"]["error"] . "";
}
else
{
$f = $output_dir. $_FILES["file"]["name"];
 move_uploaded_file($_FILES["file"]["tmp_name"],$output_dir. $_FILES["file"]["name"]);					}
?>
			<h2 style="text-align:center;">Generate Report</h2>

<form action="example.php" method="post" enctype="multipart/form-data" style="margin-top:20%;">
		<div style="position:relative;float:right;margin-right:45%;"> 
			<input type="submit" value="Error Proceed" name="submit">
		</div>
</form>
<form action="master.php" method="post" enctype="multipart/form-data" style="margin-top:20%;">
		<div style="position:relative;float:right;margin-right:45%;"> 
			<input type="submit" value="Master Proceed" name="submit">
		</div>
</form>
<?php
}
else{
echo "F";
}
?>