<?php
require_once('connect.php');

?>
<html>
	<head>
		<meta charset="utf-8">
		<title>Invoice</title>
		<link rel="stylesheet" href="css/styles.css">
		<style>
		.button {
			background-color: #4CAF50; /* Green */
			border: none;
			color: white;
			padding: 15px 32px;
			/* text-align: center; */
			text-decoration: none;
			display: inline-block;
			font-size: 16px;
		}

#btncompare {
  position: fixed;
  right: 24px;
  bottom: 31px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
#btnhis {
  position: fixed;
  right: 24px;
  bottom: 80px;
  z-index: 9999;
  font-size: 12px;
  background-color: #000;
  border-color: #000;
  display: block;
  height: 40px;
  width: 144px;
}
		</style>
	</head>
	<body>
	
	<div class="compare_drpdn">
			<a href="inventory.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btncompare"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Inventory </span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>
	<div class="compare_drpdn">
			<a href="old/bill.php" id="compare_button" class="compare_dropbtn">
			<button type="button" class="btn btn-raised btn-primary" id="btnhis"/>
		  <span style="font-weight:500;font-size:14px;color:#fff"><B>Old Bill</span>
		  <span class="compare_count" style=""></B></span></button>
		</a>
	</div>

	<div class="content">
	<div style="text-align:left;float:left;">
		<span>Outlet Billing History</span><br>
	</div>
	<div style="text-align:right;">		
		<a class="button" href ="logout.php">Logout</a>
	</div>
	<br>
		<article>
			<table class="inventory">
				<thead>
					<tr>
						<th><span >Customer</span></th>
						<th><span >Bill-No</span></th>
						<th><span >Quantity</span></th>
						<th><span >Amount</span></th>
						<th><span >Date</span></th>
					</tr>				
					</thead>

					<?php 
						$get_bill = mysqli_query($con,"SELECT number,bill_no,count(quant) as quant, sum(final_value) as total, time FROM billing GROUP BY bill_no ORDER BY time DESC ");
						while($row = mysqli_fetch_array($get_bill))
						{
							?>
							<tr>
								<td><span ><?php echo $row['number'];?></span></td>
								<td><span style="font-size:11px;"><?php echo $row['bill_no'];?></span></td>
								<td><span ><?php echo $row['quant'];?></span></td>
								<td><span ><?php echo $row['total'];?></span></td>
								<td><span ><?php echo $row['time'];?></span></td>
							</tr>
					<?php	
					}
					?>
				<tbody class="new_inv">
					
				</tbody>
			</table>
			
		</article>
</div>




<script src="js/ajax.js"></script>

	</body>
</html>