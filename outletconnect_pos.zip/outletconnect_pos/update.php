<?php

require_once('connect.php');
$flag=0;
if(isset($_GET['number']))
{
	$numb = $_GET['number'];  	
	
	if($numb=="0")
	{
		$get_info = mysqli_query($con,"SELECT * FROM live_bill where flag='0' && counter_id = 'Counter1'");
		while($row = mysqli_fetch_array($get_info))
		{
			$numbe = $row['number'];
			$bill_no = $row['bill_no'];
			$prod_name = $row['prod_name'];
			$quant = $row['quant'];
			$price = $row['price'];
			$bill_no = $row['bill_no'];
			$exp = $row['exp'];
			echo $price."_";
			echo $numbe."_";
			echo $bill_no."_";
			echo $prod_name."_";
			echo $quant."_";
			echo $bill_no."_";
			echo $exp."_";
			$flag = 1;
			$sql = "UPDATE live_bill SET flag = '1' WHERE  prod_name= '$prod_name' && quant = '$quant' ";
			if ($con->query($sql) === TRUE) {
				
			} else {
				
			}
			$sql = "UPDATE status SET web = '1'";
			if ($con->query($sql) === TRUE) {
				
			} else {
				
			}
		}
		if($flag==0)
			echo "na_";
	}
	else
	{
		$get_info = mysqli_query($con,"SELECT * FROM live_bill where number='$numb' && flag!=1 && counter_id = 'Counter1'");
		while($row = mysqli_fetch_array($get_info))
		{
			$numbe = $row['number'];
			$bill_no = $row['bill_no'];
			$prod_name = $row['prod_name'];
			$quant = $row['quant'];
			$price = $row['price'];
			$bill_no = $row['bill_no'];
			$exp = $row['exp'];
			echo $price."_";
			echo $numbe."_";
			echo $bill_no."_";
			echo $prod_name."_";
			echo $quant."_";
			echo $bill_no."_";
			echo $exp."_";
			$flag = 1;
			$sql = "UPDATE live_bill SET flag = '1' WHERE  prod_name= '$prod_name' && quant = '$quant' ";
			if ($con->query($sql) === TRUE) {
				
			} else {
				
			}
			$sql = "UPDATE status SET web = '1'";
			if ($con->query($sql) === TRUE) {
				
			} else {
				
			}
		}
		if($flag==0)
			echo "na_";
	}
}
?>
	