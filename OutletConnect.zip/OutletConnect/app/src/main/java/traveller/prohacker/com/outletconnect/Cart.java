package traveller.prohacker.com.outletconnect;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class Cart extends AppCompatActivity {
    // DB Class to perform DB related operations
    DBController controller = new DBController(this);
    // Progress Dialog Object
    ProgressDialog prgDialog;
    private String product_name,price,quantity;
    TextView pname,amount,pqty;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cart);
        ArrayList<HashMap<String, String>> userList = controller.get_product_order();
        // If users exists in SQLite DB
        if (userList.size() != 0) {
            ListAdapter adapter = new SimpleAdapter(Cart.this,
                    userList, R.layout.view_user_entry_cart, new String[]{
                    "product_name", "price", "quantity"}, new int[]{R.id.pname, R.id.amount, R.id.pqty});
            final ListView myList = (ListView) findViewById(android.R.id.list);
            myList.setAdapter(adapter);
        }




    }

}
