package traveller.prohacker.com.outletconnect;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class Search extends AppCompatActivity {
    // List view
    private ListView lv;
    // Listview Adapter
    ArrayAdapter<String> adapter,adapter1;
    // Search EditText
    EditText inputSearch;
    // ArrayList for Listview
    ArrayList<HashMap<String, String>> productList;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        // Listview Data
        String products[] = {"Sunsilk", "Surf Excel", "Kissan", "Dove", "Axe",
                "Cif", "Comfort","Cornetto",
                "Lipton", "Lifebuoy", "Lux", "Pepsodent","Pond's","Vaseline","TRESemme","Wheel",
                "aviance"};

        final String price[] = {"Rs 132", "Rs 207", "Rs 52", "Rs 174", "Rs 195",
                "Rs 50","Rs 50",
                "Rs 315", "Rs 209", "Rs 105", "Rs 90","Rs 75","Rs 85","Rs 154","Rs 48",
                "Rs 199"};

        lv = (ListView) findViewById(R.id.list_view);
        inputSearch = (EditText) findViewById(R.id.inputSearch);

        // Adding items to listview
        adapter = new ArrayAdapter<String>(this, R.layout.search_card, R.id.textView2, products);
        lv.setAdapter(adapter);
        final ListView myList = (ListView) findViewById(R.id.list_view);
        myList.setAdapter(adapter);
        myList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                // ListView Clicked item index
                int itemPosition = i;

                // ListView Clicked item value
                TextView listText = (TextView) view.findViewById(R.id.textView2);
                String name = listText.getText().toString();
                Intent buy;
                buy = new Intent(getApplicationContext(), Product.class);
                buy.putExtra("pro_name", name);
                buy.putExtra("pro_price", price[itemPosition]);
                startActivity(buy);
            }
        });



        /**
         * Enabling Search Filter
         * */
        inputSearch.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {
                // When user changed the Text
                Search.this.adapter.getFilter().filter(cs);
            }


            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2,
                                          int arg3) {
                // TODO Auto-generated method stub

            }

            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
            }
        });
    }
}