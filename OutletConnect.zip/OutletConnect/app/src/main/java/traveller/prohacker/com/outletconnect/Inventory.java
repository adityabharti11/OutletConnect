package traveller.prohacker.com.outletconnect;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by HP on 26-09-2017.
 */

    public class Inventory extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory);
    }
}