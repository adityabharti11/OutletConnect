package traveller.prohacker.com.outletconnect;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;

/**
 * Created by HP on 30-03-2016.
 */
public class Product extends AppCompatActivity {
    private String product_name,product_price;
    TextView name,price;
    EditText e1;
    Button b1;
    DBController controller = new DBController(this);

    HashMap<String, String> queryValues;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product);
    e1 = (EditText)findViewById(R.id.qty);
        b1 = (Button)findViewById(R.id.buy);
        product_name = getIntent().getStringExtra("pro_name");
        product_price = getIntent().getStringExtra("pro_price");
       /* Toast.makeText(getApplicationContext(),
                "Pod_name :" + product_name + "  price : " + product_price, Toast.LENGTH_LONG)
                .show();*/
        name = (TextView) findViewById(R.id.tier);
        price = (TextView) findViewById(R.id.credit_limit);

        name.setText(product_name);
        price.setText(product_price);
        final String qty = e1.getText().toString();
      //  final String tot = e1.getText().toString()*product_price;
        /*  Toast.makeText(getApplicationContext(),
                  "Pod_name :" + product_name + "  price : " + qty, Toast.LENGTH_LONG)
                .show();*/

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                queryValues = new HashMap<String, String>();
                queryValues.put("product_name",product_name);
                queryValues.put("price", product_price);
                queryValues.put("quantity",qty);
                controller.insert_product(queryValues);

                Intent i = new Intent(getApplicationContext(),
                        Cart.class);
                startActivity(i);
            }
        });
    }
}