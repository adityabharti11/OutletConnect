package traveller.prohacker.com.outletconnect;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DBController extends SQLiteOpenHelper {

	public DBController(Context applicationcontext) {
        super(applicationcontext, "hackaton_hul_team_gn.db", null, 1);
    }
	//Creates Table
	@Override
	public void onCreate(SQLiteDatabase db) {
		String query;
	//	query = "CREATE TABLE users ( userId INTEGER, userName TEXT)";
     //   database.execSQL(query);
		db.execSQL(
				"create table T_CALENDAR_INFO " +
						"(CUSTOMER_ID varchar(10) ,RS_Name varchar(100),Channel varchar(4),Business varchar(10),Region varchar(10),Area varchar(25),MOC int,Date date,Activity_Type varchar(25),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);
		db.execSQL(
				"create table T_CAPITAL_PROJECTION " +
						"(CUSTOMER_ID varchar(10) ,RS_Name varchar(100),Channel varchar(4),Business varchar(10),Region varchar(10),Area varchar(25),MOC int(4),RS_Sales int(15),RS_Sales_forecast int(15),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_CHEQUE_UTILIZATION " +
						"(CUSTOMER_ID varchar(10) ,ACCOUNTING_CLERK varchar(20),CHEQUE_BOOK_NO_FROM int(6),CHEQUE_BOOK_NO_TO int(6),CHEQUE_NUM_UTILIZED int(6),BILLING_DOCUMENT_NUMBER varchar(20),BILLING_DATE date,AMOUNT varchar(20),CHEQUE_DATE date,CLEARING_DOC varchar(10)" +
						",DOCUMENT_NO varchar(10),DOC_TYPE varchar(2),RECEIPT_DOCUMENT_NO varchar(20),YEAR int(4),BANKING_DATE date " +
						",HOUSE_BANK varchar(5),ACCOUNT_ID varchar(5),PAY_IN_SLIP_NUMBER int,PAY_IN_SLIP_DATE date" +
						",PAY_IN_SLIP_TYPE varchar(6),CHEQUE_DEPOSIT_DATE date,CREATION_DATE date,ID bigint(10),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_CUSTOMER_MSTR " +
						"(CUSTOMER_ID varchar(10) ,Country varchar(3),customer_name varchar(35),City varchar(35),region varchar(3),central_order_block varchar(2),Central_delivery_block varchar(2)" +
						",Central_deletion_flag varchar(1),Central_posting_block varchar(1)" +
						",Central_sales_block varchar(2),DEFAULT_SOLD_ID varchar(1),Legal_status varchar(2),TIMES_TAMP timestamp,PDP_DAYS varchar(30)," +
						"TIER varchar(15),CREDIT_LIMIT double,FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);
		db.execSQL(
				"create table T_DELIVERY_INFO " +
						"(CUSTOMER_ID varchar(10) ,DELIVERY_DATE date,DELIVERY_ID varchar(10),DELIVERY_TYPE varchar(4)," +
						"SHIPPING_POINT varchar(4),SHIP_TO_PARTY varchar(10),TOTAL_WEIGHT double,VOLUME double,RELEASE_TYPE varchar(4)," +
						"PLANNING_FLAG varchar(2)" +
						",CREATED_ON date,CREATED_BY varchar(12),TIME timestamp,SALES_ORG varchar(4),ORDER_COMBINATION varchar(1)" +
						",PICK_DATE date,UNLOADING_POINT varchar(25),INCOT varchar(3),ROUTE varchar(6)" +
						",SOLD_TO_PARTY varchar(10),NET_WEIGHT double,CONFIRMATION_STATUS varchar(1),DELIVERY_STATUS varchar(1)" +
						",TRANSPORTATION_STATUS varchar(1),CONFIRMED_DATE date,TRANSPORT_DATE date,INVOICE_AMOUNT int" +
						",PRODUCT varchar(200),product_qty int(6),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);
		db.execSQL(
				"create table T_INCIDENT_INFO " +
						"(CUSTOMER_ID varchar(10),Incident_ID varchar(15),Region varchar(25),Incident_type varchar(15)," +
						"Subject varchar(50),Category varchar(15),Created_On date,Status varchar(25),Solution_Details varchar(50),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_INVOICE_DETAILS " +
						"(CUSTOMER_ID varchar(10) ,Billing_Document varchar(10),Billing_Type varchar(4),Billing_category varchar(1)," +
						" SALES_DISTRIBUTION_DOC_TYPE varchar(1),SALES_DOC_CURRENCY varchar(5),Sales_Organization varchar(4),Distribution_Channel varchar(2),Pricing_procedure varchar(6)," +
						"Billing_Date date	" +
						",Accounting_Doc_Number varchar(10),Fiscal_Year int(4),Posting_period int(3),Incoterms varchar(3),Posting_Status varchar(1)" +
						",Terms_of_Payment varchar(4),Payment_Method varchar(1),ACCT_ASSIGNMENT_GROUP varchar(2),Destination_Country varchar(3)"+
						",Region varchar(3),County_code varchar(3),City_code varchar(4),Company_Code varchar(4),Net_Value varchar" +
						",Created_by varchar(12),Time timestamp,Created_on double,Payer varchar(10)" +
						",Sold_toparty varchar(10),VAT_Registration_No varchar(20),Division varchar(2)," +
						"Credit_Control_Area varchar(4),Credit_account varchar(10),Business_Place varchar(4)," +
						"Sales_Order varchar(10),Warehouse_Number varchar(3),Direct_Dispatch varchar(1),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_PAYMENT_INFO" +
						"(CUSTOMER_ID varchar(10),COMPANY_CODE varchar(10) primary key,Payment_Method varchar(10),Payment_Method_Description varchar(30),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_PENDING_CREDIT_DEBIT_NOTE" +
						"(CUSTOMER_ID varchar(10),COMPANY_CODE varchar(4),Transaction_Type varchar(20),DOCUMENT_NO varchar(20),CREDIT_DEBIT_TYPE varchar(1)," +
						"AMOUNT double,DATE_OF_DOCUMENT date,SHORT_DESC varchar(25),TRANSACTION_TYPE_DESC varchar(250),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_PROMOTION_INFO" +
						"(CUSTOMER_ID varchar(10),Promotion_ID varchar(10),Promotion_Name varchar(200),Promotion_Start_Date date,Promotion_End_Date date," +
						"Customer varchar(50),Business varchar(50),Division varchar(5),Product varchar(200),Brand varchar(10),Promotion_Status varchar(20),Investment_Type varchar(100)," +
						"MOC varchar(20),Submission_Date date,Approved_Date date,Planned_Investment_Amount double,REGION varchar(3),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);

		db.execSQL(
				"create table T_WAREHOUSE_MSTR" +
						"(Warehouse_Number varchar(3),PLANT varchar(5),LOCATION varchar(5),TIMESTAMP timestamp)"
		);
		db.execSQL(
				"create table product_order " +
						"(CUSTOMER_ID varchar(10) ,product_name varchar(100),price varchar(4),quantity varchar(10),FOREIGN KEY (CUSTOMER_ID) REFERENCES T_CUSTOMER_MSTR(CUSTOMER_ID))"
		);
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int version_old, int current_version) {
		/*String query;
		query = "DROP TABLE IF EXISTS users";
		database.execSQL(query);
        onCreate(database);*/
		db.execSQL("DROP TABLE IF EXISTS T_CALENDAR_INFO");
		db.execSQL("DROP TABLE IF EXISTS T_CAPITAL_PROJECTION");
		db.execSQL("DROP TABLE IF EXISTS T_CHEQUE_UTILIZATION");
		db.execSQL("DROP TABLE IF EXISTS T_CUSTOMER_MSTR");
		db.execSQL("DROP TABLE IF EXISTS T_DELIVERY_INFO");
		db.execSQL("DROP TABLE IF EXISTS T_INCIDENT_INFO");
		db.execSQL("DROP TABLE IF EXISTS T_INVOICE_DETAILS");
		db.execSQL("DROP TABLE IF EXISTS T_PAYMENT_INFO");
		db.execSQL("DROP TABLE IF EXISTS T_PENDING_CREDIT_DEBIT_NOTE");
		db.execSQL("DROP TABLE IF EXISTS T_PROMOTION_INFO");
		db.execSQL("DROP TABLE IF EXISTS T_WAREHOUSE_MSTR");
		onCreate(db);
	}
	
	
	/**
	 * Inserts User into SQLite DB
	 * @param queryValues
	 */
	public void insert_T_INVOICE_DETAILS(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("CUSTOMER_ID", queryValues.get("CUSTOMER_ID"));
		contentValues.put("Billing_Document", queryValues.get("Billing_Document"));
		contentValues.put("Billing_Type", queryValues.get("Billing_Type"));
		contentValues.put("Billing_category", queryValues.get("Billing_category"));
		contentValues.put("SALES_DISTRIBUTION_DOC_TYPE", queryValues.get("SALES_DISTRIBUTION_DOC_TYPE"));
		contentValues.put("SALES_DOC_CURRENCY", queryValues.get("SALES_DOC_CURRENCY"));
		contentValues.put("Sales_Organization", queryValues.get("Sales_Organization"));
		contentValues.put("Distribution_Channel", queryValues.get("Distribution_Channel"));
		contentValues.put("Pricing_procedure", queryValues.get("Pricing_procedure"));
		contentValues.put("Billing_Date", queryValues.get("Billing_Date"));
		contentValues.put("Accounting_Doc_Number", queryValues.get("Accounting_Doc_Number"));
		contentValues.put("Fiscal_Year", queryValues.get("Fiscal_Year"));
		contentValues.put("Posting_period", queryValues.get("Posting_period"));
		contentValues.put("Incoterms", queryValues.get("Incoterms"));
		contentValues.put("Posting_Status", queryValues.get("Posting_Status"));
		contentValues.put("Terms_of_Payment", queryValues.get("Terms_of_Payment"));
		contentValues.put("Payment_Method", queryValues.get("Payment_Method"));
		contentValues.put("ACCT_ASSIGNMENT_GROUP", queryValues.get("ACCT_ASSIGNMENT_GROUP"));
		contentValues.put("Destination_Country", queryValues.get("Destination_Country"));
		contentValues.put("Region", queryValues.get("Region"));
		contentValues.put("County_code", queryValues.get("County_code"));
		contentValues.put("City_code", queryValues.get("City_code"));
		contentValues.put("Company_Code", queryValues.get("Company_Code"));
		contentValues.put("Net_Value", queryValues.get("Net_Value"));
		contentValues.put("Created_by", queryValues.get("Created_by"));
		contentValues.put("Time", queryValues.get("Time"));
		contentValues.put("Created_on", queryValues.get("Created_on"));
		contentValues.put("Payer", queryValues.get("Payer"));
		contentValues.put("Sold_toparty", queryValues.get("Sold_toparty"));
		contentValues.put("VAT_Registration_No", queryValues.get("VAT_Registration_No"));
		contentValues.put("Division", queryValues.get("Division"));
		contentValues.put("Credit_Control_Area", queryValues.get("Credit_Control_Area"));

		contentValues.put("Credit_account", queryValues.get("Credit_account"));

		contentValues.put("Business_Place", queryValues.get("Business_Place"));
		contentValues.put("Sales_Order", queryValues.get("Sales_Order"));
		contentValues.put("Warehouse_Number", queryValues.get("Warehouse_Number"));
		contentValues.put("Direct_Dispatch", queryValues.get("Direct_Dispatch"));

		database.insert("T_INVOICE_DETAILS", null, contentValues);
		database.close();
	}


	public void insert_T_PENDING_CREDIT_DEBIT_NOTE(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("CUSTOMER_ID", queryValues.get("CUSTOMER_ID"));
		contentValues.put("COMPANY_CODE", queryValues.get("COMPANY_CODE"));
		contentValues.put("Transaction_Type", queryValues.get("Transaction_Type"));
		contentValues.put("DOCUMENT_NO", queryValues.get("DOCUMENT_NO"));
		contentValues.put("CREDIT_DEBIT_TYPE", queryValues.get("CREDIT_DEBIT_TYPE"));
		contentValues.put("AMOUNT", queryValues.get("AMOUNT"));
		contentValues.put("DATE_OF_DOCUMENT", queryValues.get("DATE_OF_DOCUMENT"));
		contentValues.put("SHORT_DESC", queryValues.get("SHORT_DESC"));
		contentValues.put("TRANSACTION_TYPE_DESC", queryValues.get("TRANSACTION_TYPE_DESC"));
		database.insert("T_PENDING_CREDIT_DEBIT_NOTE", null, contentValues);
		database.close();
	}



	public void insert_T_CHEQUE_UTILIZATION(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("BILLING_DOCUMENT_NUMBER", queryValues.get("BILLING_DOCUMENT_NUMBER"));
		contentValues.put("BILLING_DATE", queryValues.get("BILLING_DATE"));
		contentValues.put("AMOUNT", queryValues.get("AMOUNT"));
		contentValues.put("CHEQUE_DATE", queryValues.get("CHEQUE_DATE"));
		contentValues.put("DOCUMENT_NO", queryValues.get("DOCUMENT_NO"));
		contentValues.put("RECEIPT_DOCUMENT_NO", queryValues.get("RECEIPT_DOCUMENT_NO"));
		contentValues.put("YEAR", queryValues.get("YEAR"));
		contentValues.put("HOUSE_BANK", queryValues.get("HOUSE_BANK"));
		contentValues.put("CHEQUE_DEPOSIT_DATE", queryValues.get("CHEQUE_DEPOSIT_DATE"));
		contentValues.put("CHEQUE_BOOK_NO_TO", queryValues.get("CHEQUE_BOOK_NO_TO"));
		contentValues.put("CHEQUE_BOOK_NO_FROM", queryValues.get("CHEQUE_BOOK_NO_FROM"));
		database.insert("T_CHEQUE_UTILIZATION", null, contentValues);
		database.close();
	}

	/**
	 * Get list of Users from SQLite DB as Array List
	 * @return
	 */
	public ArrayList<HashMap<String, String>> get_T_INVOICE_DETAILS() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_INVOICE_DETAILS";
	    SQLiteDatabase database = this.getWritableDatabase();
	    Cursor cursor = database.rawQuery(selectQuery, null);
	    if (cursor.moveToFirst()) {
	        do {
	        	HashMap<String, String> map = new HashMap<String, String>();
	        	map.put("Billing_Document", cursor.getString(1));
	        	map.put("Billing_Date", cursor.getString(9));
	        	map.put("Net_Value", cursor.getString(23));
                usersList.add(map);
	        } while (cursor.moveToNext());
	    }
	    database.close();
	    return usersList;
	}

	public HashMap<String, String> get_T_INVOICE_DETAILS_specific(String documentno) {
		HashMap<String, String> usersList;
		usersList = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM T_INVOICE_DETAILS where Billing_Document='"+documentno+"'";
	    SQLiteDatabase database = this.getWritableDatabase();
	    Cursor cursor = database.rawQuery(selectQuery, null);
	    if (cursor.moveToFirst()) {
	        do {

				usersList.put("Net_Value", cursor.getString(23));
				usersList.put("Billing_Date", cursor.getString(9));
				usersList.put("Credit_account", cursor.getString(32));
				usersList.put("Warehouse_Number", cursor.getString(35));
				usersList.put("Terms_of_Payment", cursor.getString(15));
				usersList.put("Sales_Organization", cursor.getString(6));
				usersList.put("Distribution_Channel", cursor.getString(7));
			} while (cursor.moveToNext());
	    }
	    database.close();
	    return usersList;
	}

	public ArrayList<HashMap<String, String>> T_PENDING_CREDIT_DEBIT_NOTE() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_PENDING_CREDIT_DEBIT_NOTE";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("DOCUMENT_NO", cursor.getString(3));
				map.put("DATE_OF_DOCUMENT", cursor.getString(6));
				map.put("AMOUNT", cursor.getString(5));
				map.put("SHORT_DESC", cursor.getString(7));
				map.put("TRANSACTION_TYPE_DESC", cursor.getString(8));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}
	public ArrayList<HashMap<String, String>> get_T_CHEQUE_UTILIZATION() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_CHEQUE_UTILIZATION";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("BILLING_DOCUMENT_NUMBER", cursor.getString(5));
				map.put("BILLING_DATE", cursor.getString(6));
				map.put("AMOUNT", cursor.getString(7));
				map.put("DOCUMENT_NO", cursor.getString(10));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}

	public HashMap<String, String> get_T_CHEQUE_UTILIZATION_specific(String documentno) {
		HashMap<String, String> usersList;
		usersList = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM T_CHEQUE_UTILIZATION where BILLING_DOCUMENT_NUMBER='"+documentno+"'";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {

				usersList.put("BILLING_DOCUMENT_NUMBER", cursor.getString(5));
				usersList.put("BILLING_DATE", cursor.getString(6));
				usersList.put("AMOUNT", cursor.getString(7));
				usersList.put("CHEQUE_DATE", cursor.getString(8));
				usersList.put("DOCUMENT_NO", cursor.getString(10));
				usersList.put("RECEIPT_DOCUMENT_NO", cursor.getString(12));
				usersList.put("YEAR", cursor.getString(13));
				usersList.put("HOUSE_BANK", cursor.getString(15));
				usersList.put("CHEQUE_DEPOSIT_DATE", cursor.getString(20));
				usersList.put("CHEQUE_BOOK_NO_FROM", cursor.getString(2));
				usersList.put("CHEQUE_BOOK_NO_TO", cursor.getString(3));
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}

	public void insert_T_INCIDENT_INFO(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("Incident_ID", queryValues.get("Incident_ID"));
		contentValues.put("Incident_type", queryValues.get("Incident_type"));
		contentValues.put("Subject", queryValues.get("Subject"));
		contentValues.put("Created_On", queryValues.get("Created_On"));
		contentValues.put("Status", queryValues.get("Status"));
		database.insert("T_INCIDENT_INFO", null, contentValues);
		database.close();
	}

	/**
	 * Get list of Users from SQLite DB as Array List
	 * @return
	 */
	public ArrayList<HashMap<String, String>> get_T_INCIDENT_INFO() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_INCIDENT_INFO";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("Incident_ID", cursor.getString(1));
				map.put("Incident_type", cursor.getString(3));
				map.put("Subject", cursor.getString(4));
				map.put("Created_On", cursor.getString(6));
				map.put("Status", cursor.getString(7));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}
	public void insert_T_CUSTOMER_MSTR(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("CUSTOMER_ID", queryValues.get("CUSTOMER_ID"));
		contentValues.put("Country", queryValues.get("Country"));
		contentValues.put("customer_name", queryValues.get("customer_name"));
		contentValues.put("City", queryValues.get("City"));
		contentValues.put("region", queryValues.get("region"));
		contentValues.put("central_order_block", queryValues.get("central_order_block"));
		contentValues.put("Central_delivery_block", queryValues.get("Central_delivery_block"));
		contentValues.put("DEFAULT_SOLD_ID", queryValues.get("DEFAULT_SOLD_ID"));
		contentValues.put("Legal_status", queryValues.get("Legal_status"));
		contentValues.put("TIER", queryValues.get("TIER"));
		contentValues.put("CREDIT_LIMIT", queryValues.get("CREDIT_LIMIT"));
		database.insert("T_CUSTOMER_MSTR", null, contentValues);
		database.close();
	}

	/**
	 * Get list of Users from SQLite DB as Array List
	 * @return
	 */
	public ArrayList<HashMap<String, String>> get_T_CUSTOMER_Membership() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_CUSTOMER_MSTR";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("TIER", cursor.getString(14));
					map.put("CREDIT_LIMIT", cursor.getString(15));
					map.put("Legal_status", cursor.getString(11));
					map.put("central_order_block", cursor.getString(5));
					map.put("Central_delivery_block", cursor.getString(6));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}

	public void insert_T_DELIVERY_INFO(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("DELIVERY_DATE", queryValues.get("DELIVERY_DATE"));
		contentValues.put("DELIVERY_ID", queryValues.get("DELIVERY_ID"));
		contentValues.put("SHIPPING_POINT", queryValues.get("SHIPPING_POINT"));
		contentValues.put("TOTAL_WEIGHT", queryValues.get("TOTAL_WEIGHT"));
		contentValues.put("VOLUME", queryValues.get("VOLUME"));
		contentValues.put("PICK_DATE", queryValues.get("PICK_DATE"));
		contentValues.put("UNLOADING_POINT", queryValues.get("UNLOADING_POINT"));
		contentValues.put("DELIVERY_STATUS", queryValues.get("DELIVERY_STATUS"));
		contentValues.put("TRANSPORTATION_STATUS", queryValues.get("TRANSPORTATION_STATUS"));
		contentValues.put("INVOICE_AMOUNT", queryValues.get("INVOICE_AMOUNT"));
		contentValues.put("PRODUCT", queryValues.get("PRODUCT"));
		contentValues.put("product_qty", queryValues.get("product_qty"));
		database.insert("T_DELIVERY_INFO", null, contentValues);
		database.close();
	}

	public void insert_product(HashMap<String, String> queryValues) {
		SQLiteDatabase database = this.getWritableDatabase();
		ContentValues contentValues = new ContentValues();
		contentValues.put("product_name", queryValues.get("product_name"));
		contentValues.put("price", queryValues.get("price"));
		contentValues.put("quantity", queryValues.get("quantity"));
		database.insert("product_order", null, contentValues);
		database.close();
	}

	public ArrayList<HashMap<String, String>> get_product_order() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM product_order";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("product_name", cursor.getString(1));
				map.put("price", cursor.getString(2));
				map.put("quantity", cursor.getString(3));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}

	public ArrayList<HashMap<String, String>> get_T_DELIVERY_INFO() {
		ArrayList<HashMap<String, String>> usersList;
		usersList = new ArrayList<HashMap<String, String>>();
		String selectQuery = "SELECT  * FROM T_DELIVERY_INFO";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {
				HashMap<String, String> map = new HashMap<String, String>();
				map.put("DELIVERY_DATE", cursor.getString(1));
				map.put("DELIVERY_ID", cursor.getString(2));
				map.put("SHIPPING_POINT", cursor.getString(4));
				map.put("INVOICE_AMOUNT", cursor.getString(26));
				usersList.add(map);
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}

	public HashMap<String, String> get_T_DELIVERY_INFO_specific(String deliveryno) {
		HashMap<String, String> usersList;
		usersList = new HashMap<String, String>();
		String selectQuery = "SELECT  * FROM T_DELIVERY_INFO where DELIVERY_ID='"+deliveryno+"'";
		SQLiteDatabase database = this.getWritableDatabase();
		Cursor cursor = database.rawQuery(selectQuery, null);
		if (cursor.moveToFirst()) {
			do {

				usersList.put("DELIVERY_DATE", cursor.getString(1));
				usersList.put("DELIVERY_ID", cursor.getString(2));
				usersList.put("TOTAL_WEIGHT", cursor.getString(6));
				usersList.put("VOLUME", cursor.getString(7));
				usersList.put("SHIPPING_POINT", cursor.getString(4));
				usersList.put("UNLOADING_POINT", cursor.getString(16));
			} while (cursor.moveToNext());
		}
		database.close();
		return usersList;
	}
}
